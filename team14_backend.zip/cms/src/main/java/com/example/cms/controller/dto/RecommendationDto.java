package com.example.cms.controller.dto;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class RecommendationDto {
    private Long recommendationId;
    private String recommendName;
    private String description;
}
