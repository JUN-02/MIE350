package com.example.cms.controller.dto;
import lombok.Getter;
import lombok.Setter;
@Getter
@Setter
public class WishlistDto {
    private Long shoeId;
    private String userId;

}
