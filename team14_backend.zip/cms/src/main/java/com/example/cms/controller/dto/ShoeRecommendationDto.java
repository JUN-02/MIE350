package com.example.cms.controller.dto;
import com.example.cms.model.entity.ShoeRecommendation;
import com.example.cms.model.entity.ShoeRecommendationKey;
import lombok.Getter;
import lombok.Setter;
@Getter
@Setter
public class ShoeRecommendationDto {
    private String shoeId;
    private Long recommendationId;

}
