INSERT INTO users (userName, email, password, loggedIn)
VALUES ('admin','admin@hotmail.ca', 'password1', 0);

INSERT INTO shoes (shoeId, shoeName, size, brand, gender, color, price, type, image_url)
VALUES (1, 'Nike Air Max 270', 9.5, 'Nike', 'Men', 'Black/White', 150.00, 'Sports','https://static.nike.com/a/images/t_PDP_1280_v1/f_auto,q_auto:eco/65b43aba-9cc4-4931-b015-31cb92a11f7f/air-max-270-shoes-VcFpK9.png');

INSERT INTO shoes (shoeId, shoeName, size, brand, gender, color, price, type,image_url)
VALUES (2, 'Adidas Superstar', 8, 'Adidas', 'Women', 'White/Black', 80.00, 'Casual','https://bluetilesc.com/cdn/shop/products/adidassuperstaradvflatwhitecoreblackflatwhite_1000x1000.jpg?v=1643920127');

INSERT INTO shoes (shoeId, shoeName, size, brand, gender, color, price, type, image_url)
VALUES (3, 'Converse Chuck Taylor All Star', 9, 'Converse', 'Unisex', 'Red', 55.00, 'Casual','https://images.littleburgundyshoes.com/images/products/1_189223_ZM.jpg');

INSERT INTO shoes (shoeId, shoeName, size, brand, gender, color, price, type,image_url)
VALUES (4, 'Reebok Nano X1', 10, 'Reebok', 'Men', 'Black/Red', 130.00, 'Sports','https://assets.roguefitness.com/f_auto,q_auto,c_limit,w_1536,b_rgb:f8f8f8/catalog/Shoes/Training%20Shoes/Reebok/Reebok%20Nano%20X1/H02838/H02838-H_ajighk.png');

INSERT INTO shoes (shoeId, shoeName, size, brand, gender, color, price, type, image_url)
VALUES (5, 'Crocs Classic Clog', 7, 'Crocs', 'Men', 'Navy', 49.99, 'Casual','https://media.crocs.com/images/t_pdphero/f_auto%2Cq_auto/products/10001_309_ALT100/crocs');

INSERT INTO shoes (shoeId, shoeName, size, brand, gender, color, price, type,image_url)
VALUES (6, 'Skechers Go Walk Joy', 8.5, 'Skechers', 'Women', 'Gray', 50.00, 'Casual','https://www.skechers.ca/on/demandware.static/-/Sites-skechers-master/default/dwb79af441/images/large/15600_BKW.jpg');

INSERT INTO shoes (shoeId, shoeName, size, brand, gender, color, price, type,image_url)
VALUES (7, 'Fila Disruptor II', 9, 'Fila', 'Women', 'White/Navy/Red', 65.00, 'Casual','https://www.brownsshoes.com/dw/image/v2/BFTX_PRD/on/demandware.static/-/Sites-brownsshoes-master-catalog/default/dw9899e798/241518_1.jpg?sw=767&sh=867');

INSERT INTO shoes (shoeId, shoeName, size, brand, gender, color, price, type,image_url)
VALUES (8, 'New Balance Fresh Foam 1080v11', 8, 'New Balance', 'Women', 'Pink/Gray', 150.00, 'Sports','https://u7q2x7c9.stackpathcdn.com/photos/24/91/370615_3727_XL.jpg');

INSERT INTO shoes (shoeId, shoeName, size, brand, gender, color, price, type,image_url)
VALUES (9, 'Nike Air Force 1', 10, 'Nike', 'Men', 'White', 90.00, 'Casual','https://static.nike.com/a/images/c_limit,w_592,f_auto/t_product_v1/e6da41fa-1be4-4ce5-b89c-22be4f1f02d4/air-force-1-07-shoes-rWtqPn.png');

INSERT INTO shoes(shoeId, shoeName, size, brand, gender, color, price, type,image_url)
VALUES (10, 'Adidas Stan Smith', 7.5, 'Adidas', 'Women', 'White/Green', 80.00, 'Casual','https://assets.adidas.com/images/w_600,f_auto,q_auto/e01dea68cf93434bae5aac0900af99e8_9366/Stan_Smith_Shoes_White_FX5500_01_standard.jpg');

INSERT INTO shoes (shoeId, shoeName, size, brand, gender, color, price, type,image_url)
VALUES (11, 'Converse Chuck 70', 8, 'Converse', 'Men', 'Black', 80.00, 'Casual','https://converse.ca/media/catalog/product/cache/f9d46213ae1d882c35b397bec3e31308/1/6/162050c_a_107x1_1.jpg');

INSERT INTO shoes(shoeId, shoeName, size, brand, gender, color, price, type)
VALUES (12, 'Reebok Classic Leather', 9, 'Reebok', 'Women', 'White/Gum', 75.00, 'Casual');

INSERT INTO shoes (shoeId, shoeName, size, brand, gender, color, price, type)
VALUES (13, 'Crocs Bistro Clog', 11, 'Crocs', 'Men', 'Black', 44.99, 'Casual');

INSERT INTO shoes (shoeId, shoeName, size, brand, gender, color, price, type)
VALUES (14, 'Skechers D''Lites', 8, 'Skechers', 'Women', 'Black/White', 65.00, 'Casual');

INSERT INTO shoes (shoeId, shoeName, size, brand, gender, color, price, type)
VALUES (15, 'Fila Ray Tracer', 9, 'Fila', 'Men', 'Black/Red', 75.00, 'Casual');

INSERT INTO shoes (shoeId, shoeName, size, brand, gender, color, price, type)
VALUES (16, 'New Balance 574', 8.5, 'New Balance', 'Men', 'Grey/Navy', 80.00, 'Casual');

INSERT INTO shoes(shoeId, shoeName, size, brand, gender, color, price, type)
VALUES (17, 'Nike React Infinity Run Flyknit', 9, 'Nike', 'Women', 'Pink/Black', 160.00, 'Sports');

INSERT INTO shoes (shoeId, shoeName, size, brand, gender, color, price, type)
VALUES (18, 'Adidas NMD_R1', 7, 'Adidas', 'Women', 'Black/Pink', 130.00, 'Sports');

INSERT INTO shoes (shoeId, shoeName, size, brand, gender, color, price, type)
VALUES (19, 'Converse Chuck Taylor All Star High Top', 8, 'Converse', 'Men', 'Red', 60.00, 'Casual');

INSERT INTO shoes (shoeId, shoeName, size, brand, gender, color, price, type)
VALUES (20, 'Reebok Club C 85', 10, 'Reebok', 'Men', 'White/Green', 75.00, 'Casual');

INSERT INTO shoes (shoeId, shoeName, size, brand, gender, color, price, type)
VALUES (21, 'Nike Air Max Excee', 9, 'Nike', 'Men', 'Black/White', 90.00, 'Casual');

INSERT INTO shoes (shoeId, shoeName, size, brand, gender, color, price, type)
VALUES (22, 'Adidas Grand Court', 8, 'Adidas', 'Women', 'White/Black', 65.00, 'Casual');

INSERT INTO shoes (shoeId, shoeName, size, brand, gender, color, price, type)
VALUES (23, 'Converse Chuck Taylor All Star', 9, 'Converse', 'Unisex', 'Red', 55.00, 'Casual');

INSERT INTO shoes (shoeId, shoeName, size, brand, gender, color, price, type)
VALUES (24, 'Reebok Club C 85', 10, 'Reebok', 'Men', 'Black/White', 75.00, 'Casual');

INSERT INTO shoes (shoeId, shoeName, size, brand, gender, color, price, type)
VALUES (25, 'Crocs Classic Clog', 7, 'Crocs', 'Men', 'Navy', 49.99, 'Casual');

INSERT INTO shoes (shoeId, shoeName, size, brand, gender, color, price, type)
VALUES (27, 'Fila Memory Workshift', 9, 'Fila', 'Women', 'White', 55.00, 'Casual');

INSERT INTO shoes (shoeId, shoeName, size, brand, gender, color, price, type)
VALUES (28, 'New Balance 680v6', 8, 'New Balance', 'Women', 'Blue', 75.00, 'Running');

INSERT INTO shoes (shoeId, shoeName, size, brand, gender, color, price, type)
VALUES (29, 'Nike Revolution 5', 10, 'Nike', 'Men', 'Gray/Red', 65.00, 'Running');

INSERT INTO shoes (shoeId, shoeName, size, brand, gender, color, price, type)
VALUES (30, 'Adidas Lite Racer Adapt 3.0', 7.5, 'Adidas', 'Women', 'Black/Pink', 60.00, 'Casual');

INSERT INTO shoes (shoeId, shoeName, size, brand, gender, color, price, type)
VALUES (31, 'Converse Chuck 70 High Top', 8, 'Converse', 'Men', 'Black', 80.00, 'Casual');

INSERT INTO shoes (shoeId, shoeName, size, brand, gender, color, price, type)
VALUES (32, 'Reebok Nano X', 9, 'Reebok', 'Women', 'Pink/Black', 130.00, 'Sports');

INSERT INTO shoes (shoeId, shoeName, size, brand, gender, color, price, type)
VALUES (33, 'Crocs Classic Lined Clog', 11, 'Crocs', 'Men', 'Brown', 55.00, 'Casual');

INSERT INTO shoes (shoeId, shoeName, size, brand, gender, color, price, type)
VALUES (34, 'Skechers Go Run Fast', 8, 'Skechers', 'Women', 'Navy/Pink', 70.00, 'Running');

INSERT INTO shoes (shoeId, shoeName, size, brand, gender, color, price, type)
VALUES (35, 'Fila Memory Faction', 9.5, 'Fila', 'Men', 'Gray/Blue', 60.00, 'Casual');

INSERT INTO shoes (shoeId, shoeName, size, brand, gender, color, price, type)
VALUES (36, 'New Balance Fresh Foam Arishi v3', 8.5, 'New Balance', 'Women', 'Black/White', 70.00, 'Running');

INSERT INTO shoes (shoeId, shoeName, size, brand, gender, color, price, type)
VALUES (37, 'Nike Air Zoom Pegasus 38', 9, 'Nike', 'Men', 'Blue/White', 120.00, 'Running');

INSERT INTO shoes (shoeId, shoeName, size, brand, gender, color, price, type)
VALUES (38, 'Adidas Ultraboost 21', 8, 'Adidas', 'Women', 'Black/Purple', 180.00, 'Sports');

INSERT INTO shoes (shoeId, shoeName, size, brand, gender, color, price, type)
VALUES (39, 'Converse Chuck Taylor All Star Shoreline', 10, 'Converse', 'Women', 'White', 55.00, 'Casual');

INSERT INTO shoes (shoeId, shoeName, size, brand, gender, color, price, type)
VALUES (41, 'Puma RS-X3 Puzzle', 9, 'Puma', 'Men', 'Gray/Black', 100.00, 'Casual');

INSERT INTO ratings (ratingId, userName, ratingScore, description, shoeId)
VALUES (1, 'admin', 3.0,  'Horrific', 1);

INSERT INTO ratings (ratingId, userName, ratingScore, description, shoeId)
VALUES (2, 'admin', 4.0,  'Meh', 5);

INSERT INTO ratings (ratingId, userName, ratingScore, description, shoeId)
VALUES (3, 'admin', 5.0, 'Bowling ball part 5', 7);

INSERT INTO shoeWish (shoeId,userName)
VALUES (1,'admin');
INSERT INTO shoeWish (shoeId,userName)
VALUES (38,'admin');
INSERT INTO shoeWish (shoeId,userName)
VALUES (22,'admin');
INSERT INTO shoeWish (shoeId,userName)
VALUES (5,'admin');

INSERT INTO recommendations (recommendationId, recommendName, description)
VALUES (1,'Free-entry to Construction Site drip', 'Title self-explanatory');

INSERT INTO recommendations (recommendationId, recommendName, description)
VALUES (2,'McDonalds General Manager Drip', 'Flip my burger');

INSERT INTO shoeRecs (shoeId, recommendationId)
VALUES (1,1);

INSERT INTO shoeRecs (shoeId, recommendationId)
VALUES (2,1);

INSERT INTO shoeRecs (shoeId, recommendationId)
VALUES (5,1);

INSERT INTO shoeRecs (shoeId, recommendationId)
VALUES (7,1);

INSERT INTO shoeRecs (shoeId, recommendationId)
VALUES (10,1);

INSERT INTO shoeRecs (shoeId, recommendationId)
VALUES (5,2);

INSERT INTO shoeRecs (shoeId, recommendationId)
VALUES (20,2);

INSERT INTO shoeRecs (shoeId, recommendationId)
VALUES (28,2);